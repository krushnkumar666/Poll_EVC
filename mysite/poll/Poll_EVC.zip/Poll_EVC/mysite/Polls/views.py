from django.shortcuts import render
from django.http import HttpResponse
from django.shortcuts import render
from .models import Question, Choice


# Create your views here.

def index(request):
    qstobj = Question.objects.all()
    return render(request, 'Polls/index.html', {'qst' : qstobj})


def showchoices(request, question_id):
    qstobj = Question.objects.get(pk=question_id)
    return render(request, 'Polls/choices.html', {'choice' : qstobj})


def voted(request, question_id):
    if request.method == 'POST':
        qstobj = Question.objects.get(pk=question_id)
        try:
            choiceobj = get_object_or_404(Choice, pk=request.POST['choice'])
        except:
            return HttpResponse('Voted Succesfully')
        else:
            choiceobj.votes += 1
            choiceobj.save()
            return render(request, 'Polls/choices.html', {'choic':qstobj})
    else:
        return render(request, 'Polls/choices.html')


